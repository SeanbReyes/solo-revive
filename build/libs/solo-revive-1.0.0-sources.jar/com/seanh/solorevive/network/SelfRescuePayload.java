package com.seanh.solorevive.network;

import com.seanh.solorevive.SoloRevive;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SelfRescuePayload(boolean pressed)
        implements class_8710 {

    public static final class_9154<SelfRescuePayload> TYPE =
            new class_9154<>(
                    class_2960.method_60655(
                            SoloRevive.MOD_ID,
                            "self_rescue"
                    )
            );

    public static final class_9139<
            class_9129,
            SelfRescuePayload
            > STREAM_CODEC =
            class_9139.method_56434(
                    class_9135.field_48547,
                    SelfRescuePayload::pressed,
                    SelfRescuePayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
