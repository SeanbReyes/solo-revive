package com.seanh.solorevive;

import com.seanh.solorevive.network.SelfRescueNetworking;

import ichttt.mods.firstaid.FirstAid;
import ichttt.mods.firstaid.common.RegistryObjects;
import ichttt.mods.firstaid.common.damagesystem.PlayerDamageModel;
import ichttt.mods.firstaid.common.util.CommonUtils;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SelfRescueManager {

    /*
     * El rescue normal de First Aid New dura 160 ticks.
     */
    private static final int RESCUE_DURATION_TICKS = 160;
    private static final class_1792 BANDAGE =
        class_7923.field_41178.method_10223(
                class_2960.method_60655(
                        "firstaid",
                        "bandage"
                )
        )
        .orElseThrow()
        .comp_349();

    /*
     * El auto-rescate requiere 3 vendas.
     */
    private static final int REQUIRED_BANDAGES = 3;

    private static final Map<UUID, Integer> progress =
            new HashMap<>();

    private static final Map<UUID, Boolean> keyStates =
            new HashMap<>();

    private SelfRescueManager() {
    }

    public static void initialize() {

        SelfRescueNetworking.initialize();

        ServerTickEvents.END_SERVER_TICK.register(
                SelfRescueManager::tick
        );
    }

    public static void setKeyState(
            class_3222 player,
            boolean pressed
    ) {
        UUID uuid = player.method_5667();

        keyStates.put(uuid, pressed);

        /*
         * Soltar R cancela inmediatamente el progreso.
         */
        if (!pressed) {
            progress.remove(uuid);
        }
    }

    private static void tick(
            MinecraftServer server
    ) {

        /*
         * Si hay más de un jugador conectado,
         * First Aid New funciona completamente normal.
         */
        if (server.method_3760()
                .method_14571()
                .size() != 1) {

            progress.clear();

            return;
        }

        class_3222 player =
                server.method_3760()
                        .method_14571()
                        .getFirst();

        UUID uuid =
                player.method_5667();

        /*
         * La tecla debe estar siendo mantenida.
         */
        if (!keyStates.getOrDefault(uuid, false)) {

            progress.remove(uuid);

            return;
        }

        /*
         * Obtener el modelo real de First Aid New.
         */
        PlayerDamageModel damageModel =
                CommonUtils.getDamageModel(player)
                        instanceof PlayerDamageModel model
                                ? model
                                : null;

        if (damageModel == null) {

            progress.remove(uuid);

            return;
        }

        /*
         * El jugador debe estar en una condición
         * rescatable de First Aid New.
         */
        if (!damageModel.canBeRescued()) {

            progress.remove(uuid);

            return;
        }

        /*
         * Debe tener 3 vendas.
         */
        if (!hasBandages(
                player,
                REQUIRED_BANDAGES
        )) {

            progress.remove(uuid);

            return;
        }

        /*
         * Incrementar progreso.
         */
        int currentProgress =
                progress.getOrDefault(uuid, 0) + 1;

        progress.put(
                uuid,
                currentProgress
        );

        /*
         * Todavía no terminó.
         */
        if (currentProgress
                < RESCUE_DURATION_TICKS) {

            return;
        }

        /*
         * Comprobación final antes de consumir.
         */
        if (!hasBandages(
                player,
                REQUIRED_BANDAGES
        )) {

            progress.remove(uuid);

            return;
        }

        /*
         * Consumir 3 vendas.
         */
        removeBandages(
                player,
                REQUIRED_BANDAGES
        );

        /*
         * Usar la lógica oficial de First Aid New.
         *
         * Esto no crea una curación paralela.
         * First Aid New se encarga de la recuperación.
         */
        boolean rescued =
                damageModel.rescueFromCriticalState(
                        player,
                        null,
                        FirstAid.rescueWakeUpEnabled
                );

        if (rescued) {

            player.method_64398(
                    net.minecraft.class_2561.method_43470(
                            "You rescued yourself using 3 bandages."
                    )
            );
        }

        progress.remove(uuid);
    }

    private static boolean hasBandages(
        class_3222 player,
        int amount
) {
    int count = 0;

    for (
            int slot = 0;
            slot < player.method_31548()
                    .method_5439();
            slot++
    ) {
        class_1799 stack =
                player.method_31548()
                        .method_5438(slot);

        if (!stack.method_31574(BANDAGE)) {
            continue;
        }

        count += stack.method_7947();

        if (count >= amount) {
            return true;
        }
    }

    return false;
}

    private static void removeBandages(
        class_3222 player,
        int amount
) {
    int remaining = amount;

    for (
            int slot = 0;
            slot < player.method_31548()
                    .method_5439()
                    && remaining > 0;
            slot++
    ) {
        class_1799 stack =
                player.method_31548()
                        .method_5438(slot);

        if (!stack.method_31574(BANDAGE)) {
            continue;
        }

        int removed =
                Math.min(
                        remaining,
                        stack.method_7947()
                );

        stack.method_7934(removed);

        remaining -= removed;
    }
}
}
