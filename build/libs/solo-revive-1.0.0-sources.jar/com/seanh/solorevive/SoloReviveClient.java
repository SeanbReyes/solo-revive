package com.seanh.solorevive;

import com.seanh.solorevive.network.SelfRescuePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class SoloReviveClient
        implements ClientModInitializer {

    private static class_304 selfRescueKey;

    private static boolean previousPressed = false;

    private static int keepAliveTimer = 0;

    private static final class_304.class_11900 SOLO_REVIVE_CATEGORY =
        class_304.class_11900.method_74698(
                class_2960.method_60655(
                        "solo_revive",
                        "self_rescue"
                )
        );

    @Override
    public void onInitializeClient() {

        selfRescueKey =
                KeyBindingHelper.registerKeyBinding(
                        new class_304(
                                "key.solo_revive.self_rescue",
                                class_3675.class_307.field_1668,
                                GLFW.GLFW_KEY_R,
                                SOLO_REVIVE_CATEGORY
                        )
                );

        ClientTickEvents.END_CLIENT_TICK.register(
                SoloReviveClient::tick
        );
    }

    private static void tick(class_310 client) {

        if (client.field_1724 == null) {
            return;
        }

        boolean pressed =
                selfRescueKey.method_1434();

        if (pressed != previousPressed) {

            previousPressed = pressed;

            ClientPlayNetworking.send(
                    new SelfRescuePayload(pressed)
            );

            keepAliveTimer = 0;

            return;
        }

        if (pressed) {

            keepAliveTimer++;

            if (keepAliveTimer >= 5) {

                ClientPlayNetworking.send(
                        new SelfRescuePayload(true)
                );

                keepAliveTimer = 0;
            }
        }
    }
}
